import { apiClient } from './api';

export const chatService = {
  initLead(data) {
    return apiClient.post('/chat/init-lead', data);
  },

  query(data) {
    return apiClient.post('/chat/query', data);
  },

  getConversation(conversationId) {
    return apiClient.get(`/chat/conversations/${conversationId}`);
  },

  getMessages(conversationId, limit = 30, before) {
    const params = new URLSearchParams({ limit: String(limit) });
    if (before) params.set('before', before);
    return apiClient.get(`/chat/conversations/${conversationId}/messages?${params}`);
  },

  updateStatus(conversationId, status) {
    return apiClient.patch(`/chat/conversations/${conversationId}/status`, { status });
  },

  assignConversation(conversationId, staffId) {
    return apiClient.patch(`/chat/conversations/${conversationId}/assign`, { staff_id: staffId });
  },
};
